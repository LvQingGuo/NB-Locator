/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc;

UART_HandleTypeDef hlpuart1;
UART_HandleTypeDef huart2;

TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
// 串口接收缓冲区及标志（外部变量，在stm32l0xx_it.c中定义）
extern uint8_t Res2_Buf[256]; // Res2接收缓冲区（USART2调试串口接收数据）
extern uint8_t Res2_Sign;	  // Res2接收完成标志（1：接收完成）
extern uint8_t Res2_Count;	  // Res2接收字节数
extern uint8_t Res2;		  // Res2超时计数（用于判断接收结束）

extern uint8_t Res1_Buf[256]; // Res1接收缓冲区（LPUART1接收NB模块数据）
extern uint8_t Res1_Sign;	  // Res1接收完成标志
extern uint8_t Res1_Count;	  // Res1接收字节数
extern uint8_t Res1;		  // Res1超时计数

// 电池相关变量
uint16_t BAT_DATA;	   // 电池ADC原始数据
float BAT_Value;	   // 电池电压值（V）
float VDDA_Value;	   // 参考电压值（V）
uint16_t VREFINT_CAL;  // 内部参考电压校准值（芯片出厂预设）
uint16_t VREFINT_DATA; // 内部参考电压ADC原始数据
uint8_t BAT_Q;		   // 电池电量（0-100%）
uint8_t BAT_Q_Last;	   // 上一次电池电量（用于判断是否需要上传）

// NB模块相关变量
uint8_t NB_Signal_Value; // NB模块信号强度
// NB模块AT指令模板（用于与OneNET平台通信的MIPL协议指令）
uint8_t NB_OBSERVERSP_CMD[50] = "AT+MIPLOBSERVERSP=0,";	  // 观察者响应指令
uint8_t NB_DISCOVERRSP_CMD[50] = "AT+MIPLDISCOVERRSP=0,"; // 发现响应指令
uint8_t NB_NOTIFY5700_CMD[60] = "AT+MIPLNOTIFY=0,";		  // 电池电量上报指令（对象5700）
uint8_t NB_NOTIFY5513_CMD[60] = "AT+MIPLNOTIFY=0,";		  // 纬度上报指令（对象5513）
uint8_t NB_NOTIFY5514_CMD[60] = "AT+MIPLNOTIFY=0,";		  // 经度上报指令（对象5514）
uint8_t NB_OB3320_count;								  // 3320对象ID长度（用于指令拼接）
uint8_t NB_OB3336_count;								  // 3336对象ID长度（用于指令拼接）
uint8_t onenet_ok = 0;									  // OneNET平台连接状态（0：未连接，2：已连接）

// GNSS定位相关变量
uint32_t temp_int;	  // 临时整数变量
float temp_float;	  // 临时浮点数变量
uint32_t weidu_int;	  // 纬度整数形式（放大1e6倍）
float weidu_float;	  // 纬度浮点数
uint32_t jingdu_int;  // 经度整数形式（放大1e6倍）
float jingdu_float;	  // 经度浮点数

// TIM2定时中断标志位
uint8_t interuptFlag = 0;

// 关机计数（低电量时触发）
uint8_t shutdown = 0; 
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC_Init(void);
static void MX_LPUART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
void Get_BAT_Value(void);									// 获取电池电压及电量
void Read_Filter_Battery_Voltage(void);						// 读取并滤波电池电压
uint8_t Calculate_Battery_Percentage(float voltage);		// 计算电池百分比
uint8_t Send_Cmd(uint8_t *cmd, uint8_t len, char *recdata); // 发送AT指令并检查响应
void NB_Rec_Handle(void);									// 处理NB模块接收的数据
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// 重定向fputc函数，使printf通过USART2输出（调试用）
int fputc(int ch, FILE *f)
{
	while ((USART2->ISR & 0X40) == 0)
		;					   // 等待发送缓冲区为空
	USART2->TDR = (uint8_t)ch; // 发送字符
	return ch;
}
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{
	/* USER CODE BEGIN 1 */
	
	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_ADC_Init();
	MX_LPUART1_UART_Init();
	MX_USART2_UART_Init();
	MX_TIM2_Init();
	/* USER CODE BEGIN 2 */
	// 硬件初始化流程
	HAL_GPIO_WritePin(PWR_LED_GPIO_Port, PWR_LED_Pin, GPIO_PIN_RESET); // 点亮电源指示灯
	HAL_GPIO_WritePin(GPIOA, PWR_EN_Pin, GPIO_PIN_SET);				   // 开启电源
	while (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == 0); 				   // 等待硬件就绪
	// 初始化NB模块（BC20）：上电
	HAL_GPIO_WritePin(GPIOA, NB_PWR_Pin, GPIO_PIN_SET);
	HAL_Delay(600);
	HAL_GPIO_WritePin(GPIOA, NB_PWR_Pin, GPIO_PIN_RESET);
	// 初始化NB模块（BC20）：复位(防止出现短时间内连续下载程序到板子上出现错误)
	HAL_GPIO_WritePin(GPIOA, NB_RST_Pin, GPIO_PIN_SET);
	HAL_Delay(60);
	HAL_GPIO_WritePin(GPIOA, NB_RST_Pin, GPIO_PIN_RESET);
	HAL_Delay(10000); // 等待模块启动

	// 检查NB模块是否就绪（发送AT指令，等待OK响应）
	while (Send_Cmd((uint8_t *)"AT\r\n", 4, "OK") != 0)
	{
		HAL_Delay(1000);
	}
	printf("BC20 module ready\r\n");

	// 关闭NB模块回显（避免接收冗余数据）
	while (Send_Cmd((uint8_t *)"ATE0\r\n", 6, "OK") != 0)
	{
		HAL_Delay(1000);
	}
	printf("The echo has been turned off\r\n");

	// 获取NB模块信号强度（解析+CSQ指令响应）
	NB_Signal_Value = 0;
	while ((NB_Signal_Value == 0) || (NB_Signal_Value == 99)) // 0和99为无效信号
	{
		if (Send_Cmd((uint8_t *)"AT+CSQ\r\n", 8, "OK") == 0)
		{
			if (Res1_Buf[2] == '+')
			{
				if (Res1_Buf[9] == ',') // 信号值为个位数
					NB_Signal_Value = Res1_Buf[8] - 0x30;
				else if (Res1_Buf[10] == ',') // 信号值为两位数
					NB_Signal_Value = (Res1_Buf[8] - 0x30) * 10 + (Res1_Buf[9] - 0x30);
			}
		}
		HAL_Delay(1000);
	}
	printf("NB_Signal_Value(0-31, 31 is the strongest, 99 has no signal)=%d\r\n", NB_Signal_Value);

	// 等待NB模块注册到EPS网络（+CEREG: 0,1表示注册成功）
	while (Send_Cmd((uint8_t *)"AT+CEREG?\r\n", 11, "+CEREG: 0,1") != 0)
	{
		HAL_Delay(1000);
	}
	printf("EPS online registration successful\r\n");

	// 等待PS附着成功（+CGATT: 1表示附着成功）
	while (Send_Cmd((uint8_t *)"AT+CGATT?\r\n", 11, "+CGATT: 1") != 0)
	{
		HAL_Delay(1000);
	}
	printf("PS has been attached\r\n");

	// 开启GNSS模块（卫星定位）
	while (Send_Cmd((uint8_t *)"AT+QGNSSC=1\r\n", 13, "OK") != 0)
	{
		HAL_Delay(1000);
	}
	printf("The GNSS function has been enabled\r\n");
	HAL_Delay(2000);

	// 确认GNSS模块已开启
	while (Send_Cmd((uint8_t *)"AT+QGNSSC?\r\n", 12, "+QGNSSC: 1") != 0)
	{
		HAL_Delay(1000);
	}
	printf("The GNSS module has been enabled\r\n");

	// 初始化OneNET平台通信（MIPL协议）
	Send_Cmd((uint8_t *)"AT+MIPLCREATE\r\n", 15, "OK"); // 创建MIPL实例
	HAL_Delay(100);
	Send_Cmd((uint8_t *)"AT+MIPLADDOBJ=0,3320,1,\"1\",1,0\r\n", 32, "OK"); // 添加3320对象（电池相关）
	Send_Cmd((uint8_t *)"AT+MIPLADDOBJ=0,3336,1,\"1\",2,0\r\n", 32, "OK"); // 添加3336对象（定位相关）
	HAL_Delay(100);
	Send_Cmd((uint8_t *)"AT+MIPLOPEN=0,86400\r\n", 21, "OK"); // 连接OneNET平台，超时86400秒

	// 所有外设初始化完成后设置中断优先级
	HAL_NVIC_SetPriority(TIM2_IRQn, 2, 0);	  // 最低优先级
	HAL_NVIC_SetPriority(LPUART1_IRQn, 0, 0); // 最高优先级（NB模块通信）
	HAL_NVIC_SetPriority(USART2_IRQn, 1, 0);  // 中等优先级（调试串口）

	HAL_TIM_Base_Start_IT(&htim2); // 启动TIM2中断(1ms定时中断)
	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
		// 处理Res2缓冲区数据（转发到NB模块）
		if (Res2_Sign == 1)
		{
			// 等待接收完成（超时10ms）
			do
			{
				Res2++;
				HAL_Delay(1);
			} while (Res2 < 10);
			Res2_Sign = 0;
			// 将Res2接收的数据转发到NB模块（LPUART1）
			HAL_UART_Transmit(&hlpuart1, Res2_Buf, Res2_Count, 1000);
			Res2_Count = 0;
		}

		// 处理Res1缓冲区数据（NB模块接收，转发到调试串口并解析）
		if (Res1_Sign == 1)
		{
			// 等待接收完成（超时10ms）
			do
			{
				Res1++;
				HAL_Delay(1);
			} while (Res1 < 10);
			Res1_Sign = 0;
			// 将NB模块接收的数据转发到调试串口（USART2）
			HAL_UART_Transmit(&huart2, Res1_Buf, Res1_Count, 1000);
			Res1_Count = 0;
			NB_Rec_Handle(); // 解析NB模块数据（如定位信息、平台指令）并上报经纬度到OneNET云平台
		}

		// 检查关机信号（低电平触发）
		if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == 0)
		{
			HAL_GPIO_WritePin(PWR_LED_GPIO_Port, PWR_LED_Pin, GPIO_PIN_SET); // 熄灭电源灯
			while (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1) == 0);			     // 等待信号释放
			HAL_GPIO_WritePin(GPIOA, BAT_ADC_EN_Pin, GPIO_PIN_SET);			 // 拉高BAT_ADC_EN，防止电池通过电阻耗电
			HAL_GPIO_WritePin(GPIOA, PWR_EN_Pin, GPIO_PIN_RESET); 			 // 关闭电源
		}

		// 定时中断标志（5秒触发一次）
		if (interuptFlag)
		{
			interuptFlag = 0; // 清除标志

			// 读取电池电压（20次采样平均滤波）
    		Read_Filter_Battery_Voltage();

			// 计算电池百分比并处理低电量关机
			BAT_Q = Calculate_Battery_Percentage(BAT_Value);
			if (BAT_Q == 0)
			{
				shutdown++;
				if (shutdown > 2) // 连续3次检测到电量为0则关机
				{
					HAL_GPIO_WritePin(GPIOA, PWR_EN_Pin, GPIO_PIN_RESET);
				}
			}

			// 若已成功连接OneNet平台，发送电池数据和GNSS查询指令
			if (onenet_ok == 2)
			{
				// 填充电池百分比到NB_NOTIFY5700_CMD指令
				NB_NOTIFY5700_CMD[33 + NB_OB3320_count] = BAT_Q / 100 + 0x30;
				NB_NOTIFY5700_CMD[34 + NB_OB3320_count] = BAT_Q % 100 / 10 + 0x30;
				NB_NOTIFY5700_CMD[35 + NB_OB3320_count] = BAT_Q % 10 + 0x30;

				// 电量变化时才发送更新
				if (BAT_Q != BAT_Q_Last)
				{
					Send_Cmd(NB_NOTIFY5700_CMD, 42 + NB_OB3320_count, "OK"); // 上报电池电量数据到云平台
					printf("Battery_Percentage=%d%\r\n", BAT_Q);
					HAL_UART_Transmit(&huart2, NB_NOTIFY5700_CMD, 42 + NB_OB3320_count, 1000); // 调试打印
					BAT_Q_Last = BAT_Q; // 更新上次电量值
				}

				// 发送GNSS数据查询指令（获取NMEA/RMC格式定位信息）
				HAL_UART_Transmit(&hlpuart1, (uint8_t *)"AT+QGNSSRD=\"NMEA/RMC\"\r\n", 23, 1000);
			}
		}
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
	RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

	/** Configure the main internal regulator output voltage
	 */
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
	{
		Error_Handler();
	}
	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2 | RCC_PERIPHCLK_LPUART1;
	PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
	PeriphClkInit.Lpuart1ClockSelection = RCC_LPUART1CLKSOURCE_PCLK1;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
	{
		Error_Handler();
	}
}

/**
 * @brief ADC Initialization Function
 * @param None
 * @retval None
 */
static void MX_ADC_Init(void)
{

	/* USER CODE BEGIN ADC_Init 0 */
	uint8_t i = 0;
	/* USER CODE END ADC_Init 0 */

	ADC_ChannelConfTypeDef sConfig = {0};

	/* USER CODE BEGIN ADC_Init 1 */

	/* USER CODE END ADC_Init 1 */

	/** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	 */
	hadc.Instance = ADC1;
	hadc.Init.OversamplingMode = DISABLE;
	hadc.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
	hadc.Init.Resolution = ADC_RESOLUTION_12B;
	hadc.Init.SamplingTime = ADC_SAMPLETIME_160CYCLES_5;
	hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
	hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc.Init.ContinuousConvMode = ENABLE;
	hadc.Init.DiscontinuousConvMode = DISABLE;
	hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc.Init.DMAContinuousRequests = DISABLE;
	hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
	hadc.Init.LowPowerAutoWait = ENABLE;
	hadc.Init.LowPowerFrequencyMode = DISABLE;
	hadc.Init.LowPowerAutoPowerOff = ENABLE;
	if (HAL_ADC_Init(&hadc) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure for the selected ADC regular channel to be converted.
	 */
	sConfig.Channel = ADC_CHANNEL_4;
	sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure for the selected ADC regular channel to be converted.
	 */
	sConfig.Channel = ADC_CHANNEL_VREFINT;
	if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN ADC_Init 2 */
	ADC1->CR |= ADC_CR_ADCAL; // 启动ADC校准
	i = 0;
	// 等待ADC校准完成，最长等待10ms
	while (((ADC1->ISR & ADC_ISR_EOCAL) != ADC_ISR_EOCAL) && (i < 10))
	{
		i++;
		HAL_Delay(1);
	}
	if (i == 10) // 校准超时
	{
		printf("ADC initialization calibration failed!\r\n");
	}
	ADC1->ISR |= ADC_ISR_EOCAL;			   // 清除校准完成标志位
	VREFINT_CAL = *(__IO uint16_t *)0x1FF80078; // 读取芯片内部参考电压校准值（存储在系统存储区）
	ADC1->CR |= ADC_CR_ADSTART;			   // 启动ADC转换
										   /* USER CODE END ADC_Init 2 */
}

/**
 * @brief LPUART1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_LPUART1_UART_Init(void)
{

	/* USER CODE BEGIN LPUART1_Init 0 */

	/* USER CODE END LPUART1_Init 0 */

	/* USER CODE BEGIN LPUART1_Init 1 */

	/* USER CODE END LPUART1_Init 1 */
	hlpuart1.Instance = LPUART1;
	hlpuart1.Init.BaudRate = 9600;
	hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
	hlpuart1.Init.StopBits = UART_STOPBITS_1;
	hlpuart1.Init.Parity = UART_PARITY_NONE;
	hlpuart1.Init.Mode = UART_MODE_TX_RX;
	hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&hlpuart1) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN LPUART1_Init 2 */
	__HAL_UART_ENABLE_IT(&hlpuart1, UART_IT_RXNE); // 使能LPUART1接收中断（连接NB模块）
												   /* USER CODE END LPUART1_Init 2 */
}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void)
{

	/* USER CODE BEGIN USART2_Init 0 */

	/* USER CODE END USART2_Init 0 */

	/* USER CODE BEGIN USART2_Init 1 */

	/* USER CODE END USART2_Init 1 */
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 9600;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN USART2_Init 2 */
	__HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE); // 使能USART2接收中断（调试串口）
												 /* USER CODE END USART2_Init 2 */
}

/**
 * @brief TIM2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_TIM2_Init(void)
{

	/* USER CODE BEGIN TIM2_Init 0 */

	/* USER CODE END TIM2_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM2_Init 1 */

	/* USER CODE END TIM2_Init 1 */
	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 8 - 1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 1000 - 1;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM2_Init 2 */

	/* USER CODE END TIM2_Init 2 */
}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	/* USER CODE BEGIN MX_GPIO_Init_1 */
	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(PWR_LED_GPIO_Port, PWR_LED_Pin, GPIO_PIN_SET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, NB_PSM_Pin | BAT_ADC_EN_Pin | NB_RST_Pin | NB_PWR_Pin | PWR_EN_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin : PWR_LED_Pin */
	GPIO_InitStruct.Pin = PWR_LED_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(PWR_LED_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : NB_PSM_Pin BAT_ADC_EN_Pin NB_RST_Pin NB_PWR_Pin
							 PWR_EN_Pin */
	GPIO_InitStruct.Pin = NB_PSM_Pin | BAT_ADC_EN_Pin | NB_RST_Pin | NB_PWR_Pin | PWR_EN_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pin : SHUT_DOWN_Pin */
	GPIO_InitStruct.Pin = SHUT_DOWN_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(SHUT_DOWN_GPIO_Port, &GPIO_InitStruct);

	/* USER CODE BEGIN MX_GPIO_Init_2 */
	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
// 定时器中断回调函数（重定义HAL库弱函数）
// HAL库头文件已包含，不需要手动提前声明
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == htim2.Instance) // 确认是TIM2中断
	{
		static uint16_t time = 0; // 累计中断次数（1ms/次）
		time++;
		if (time >= 5000) // 累计5000次即5秒
		{
			interuptFlag = 1; // 置5秒定时标志
			time = 0;		  // 重置计数
		}
	}
}

// 获取电池电压值（通过ADC采样计算）
void Get_BAT_Value(void)
{
	uint8_t i;

	// 等待ADC通道4（电池电压）转换完成（超时10ms）
	i = 0;
	while (((ADC1->ISR & ADC_ISR_EOC) != ADC_ISR_EOC) && (i < 10))
	{
		i++;
		HAL_Delay(1);
	}
	if (i == 10)
	{
		printf("Channel 4 conversion failed\r\n");
	}
	BAT_DATA = ADC1->DR; // 读取电池ADC原始值

	// 等待ADC通道VREFINT（内部参考电压）转换完成（超时10ms）
	i = 0;
	while (((ADC1->ISR & ADC_ISR_EOC) != ADC_ISR_EOC) && (i < 10))
	{
		i++;
		HAL_Delay(1);
	}
	if (i == 10)
	{
		printf("Channel 17 conversion failed\r\n");
	}
	VREFINT_DATA = ADC1->DR; // 读取内部参考电压ADC原始值

	// 计算实际参考电压（VDDA）：3.0V * 校准值 / 实际采样值
	VDDA_Value = 3.0 * VREFINT_CAL / VREFINT_DATA;
	// 计算电池电压：参考电压 * 电池ADC值 / 2048（12位ADC，量程0-VDDA，分压后需根据硬件调整）
	BAT_Value = VDDA_Value * BAT_DATA / 2048;
}

// 读取并进行20次采样平均滤波处理电池电压
void Read_Filter_Battery_Voltage(void)
{
    uint8_t i;
    float temp = 0;
    
    // 20次采样平均滤波
    for (i = 0; i < 20; i++)
    {
        Get_BAT_Value();
        temp += BAT_Value;
    }
    BAT_Value = temp / 20;
}

// 根据电池电压计算剩余百分比（基于锂电池放电曲线）
uint8_t Calculate_Battery_Percentage(float voltage)
{
	if (voltage > 4.1)
		return 100; // 4.1V以上为满电
	if (voltage < 3.0)
		return 0; // 3.0V以下为没电

	// 3.0V~4.1V之间线性计算百分比
	return (uint8_t)(100 - (4.1 - voltage) * 100 / 1.1);
}

/**
 * @brief  向NB模块发送命令并处理响应
 * @param  cmd: 待发送的命令缓冲区（uint8_t类型）
 * @param  len: 命令长度（字节数）
 * @param  recdata: 预期在响应中出现的字符串（用于匹配校验）
 * @retval uint8_t: 处理结果
 *         - 0: 成功收到响应且包含预期字符串
 *         - 1: 超时未收到任何响应
 *         - 2: 收到响应但未包含预期字符串
 */
uint8_t Send_Cmd(uint8_t *cmd, uint8_t len, char *recdata)
{
	uint8_t ret;		// 函数返回值，用于标识处理结果
	uint16_t count = 0; // 超时计数变量，用于控制等待响应的时长

	// 清空接收缓冲区（Res1_Buf为全局接收缓存，此处假设其内容以null结尾）
	memset(Res1_Buf, 0, strlen((const char *)Res1_Buf)); // Res1_Buf 强制转换为 const char *，是因为 strlen 的参数要求是字符串指针（const char *）
	// 通过LPUART1向NB模块发送命令，超时时间1000ms
	HAL_UART_Transmit(&hlpuart1, cmd, len, 1000);

	// 等待NB模块响应，最长等待300ms（循环300次，每次延迟1ms）
	// Res1_Sign为全局标志位，由接收中断置位表示有数据到达
	while ((Res1_Sign == 0) && (count < 300))
	{
		count++;
		HAL_Delay(1); // 1ms延迟，降低CPU占用
	}
	// 单片机程序（尤其是裸机程序，非 RTOS）是串行执行的，同一时间只会执行一段代码
	// 所以此处对于Res1_Sign标志位的接收判断不会与主循环的起冲突
	if (count == 300) // 超时未收到响应（Res1_Sign始终为0）
	{
		ret = 1;
	}
	else // 收到响应（Res1_Sign已置位）
	{
		// 等待接收完成（额外等待10ms，确保模块完整返回数据）
		// Res1为局部计数变量，用于控制等待时长
		do
		{
			Res1++;
			HAL_Delay(1);
		} while (Res1 < 10);

		// 将接收到的响应数据通过UART2（调试串口）转发，便于调试查看
		HAL_UART_Transmit(&huart2, Res1_Buf, Res1_Count, 1000);
		// 重置接收相关全局变量，为下一次接收做准备
		Res1_Count = 0; // Res1_Count：接收数据长度计数
		Res1_Sign = 0;	// 重置响应标志位
		ret = 2;		// 先默认标记为"收到响应但不匹配"

		// 检查接收缓冲区中是否包含预期字符串recdata
		if (strstr((const char *)Res1_Buf, recdata))
		{
			ret = 0; // 包含预期字符串，更新为成功状态
		}
	}

	return ret;
}

/**
 * @brief 处理NB模块返回的数据
 * NB_Rec_Handle函数是设备与云平台通信的核心处理函数，通过解析不同类型的指令（观察者请求、发现请求）完成协议交互，
 * 并解析 GNSS 定位数据实现位置上报，最终实现设备状态（电池、位置）与云平台的双向通信。
 */
void NB_Rec_Handle(void)
{
	uint8_t i, j; // 循环计数器：i用于计算参数长度，j用于拷贝参数

	// 处理观察者请求指令（+MIPLOBSERVE:）
	/**
	 * @brief 用于响应云平台发送的 “观察者请求”（MIPL 协议中的设备数据监听请求）
	 * 主要处理电池（3320 对象）和定位（3336 对象）相关的监听请求。
	*/
	if (strstr((const char *)Res1_Buf, "+MIPLOBSERVE:"))
	{
		// 校验指令格式：第17位应为逗号（参数分隔符）
		if (Res1_Buf[17] == ',')
		{
			i = 0;
			// 提取逗号间的参数长度（最多10位，防止缓冲区溢出）
			while (Res1_Buf[18 + i] != ',' && i <= 10)
			{
				i++;
			}

			// 参数长度超过10，视为格式错误
			if (i > 10)
			{
				printf("+MIPLOBSERVE data format error\r\n");
			}
			else
			{
				// 处理3320对象（电池相关）的观察者请求
				if (strstr((const char *)Res1_Buf, "3320"))
				{
					// 拷贝参数到响应指令缓冲区
					for (j = 0; j < i; j++)
					{
						NB_OBSERVERSP_CMD[20 + j] = Res1_Buf[18 + j]; // 观察者响应指令
						NB_NOTIFY5700_CMD[16 + j] = Res1_Buf[18 + j]; // 电池电量上报指令
					}

					// 拼接电池电量上报指令（5700为电量资源ID）
					NB_NOTIFY5700_CMD[16 + j] = ',';
					NB_NOTIFY5700_CMD[17 + j] = '3'; // 对象ID：3320
					NB_NOTIFY5700_CMD[18 + j] = '3';
					NB_NOTIFY5700_CMD[19 + j] = '2';
					NB_NOTIFY5700_CMD[20 + j] = '0';
					NB_NOTIFY5700_CMD[21 + j] = ',';
					NB_NOTIFY5700_CMD[22 + j] = '0'; // 实例ID
					NB_NOTIFY5700_CMD[23 + j] = ',';
					NB_NOTIFY5700_CMD[24 + j] = '5'; // 资源ID：5700（电量）
					NB_NOTIFY5700_CMD[25 + j] = '7';
					NB_NOTIFY5700_CMD[26 + j] = '0';
					NB_NOTIFY5700_CMD[27 + j] = '0';
					NB_NOTIFY5700_CMD[28 + j] = ',';
					NB_NOTIFY5700_CMD[29 + j] = '4'; // 数据类型：整数
					NB_NOTIFY5700_CMD[30 + j] = ',';
					NB_NOTIFY5700_CMD[31 + j] = '4'; // 数据长度
					NB_NOTIFY5700_CMD[32 + j] = ',';
					NB_NOTIFY5700_CMD[36 + j] = ',';
					NB_NOTIFY5700_CMD[37 + j] = '0'; // 标志位
					NB_NOTIFY5700_CMD[38 + j] = ',';
					NB_NOTIFY5700_CMD[39 + j] = '0';
					NB_NOTIFY5700_CMD[40 + j] = '\r'; // 指令结束符
					NB_NOTIFY5700_CMD[41 + j] = '\n';
					NB_OB3320_count = j; // 记录3320对象参数长度，用于后续指令拼接
				}
				// 处理3336对象（定位相关）的观察者请求
				else if (strstr((const char *)Res1_Buf, "3336"))
				{
					// 拷贝参数到响应指令缓冲区
					for (j = 0; j < i; j++)
					{
						NB_OBSERVERSP_CMD[20 + j] = Res1_Buf[18 + j]; // 观察者响应指令
						NB_NOTIFY5513_CMD[16 + j] = Res1_Buf[18 + j]; // 纬度上报指令
						NB_NOTIFY5514_CMD[16 + j] = Res1_Buf[18 + j]; // 经度上报指令
					}

					// 拼接纬度上报指令（5513为纬度资源ID）
					NB_NOTIFY5513_CMD[16 + j] = ',';
					NB_NOTIFY5513_CMD[17 + j] = '3'; // 对象ID：3336
					NB_NOTIFY5513_CMD[18 + j] = '3';
					NB_NOTIFY5513_CMD[19 + j] = '3';
					NB_NOTIFY5513_CMD[20 + j] = '6';
					NB_NOTIFY5513_CMD[21 + j] = ',';
					NB_NOTIFY5513_CMD[22 + j] = '0'; // 实例ID
					NB_NOTIFY5513_CMD[23 + j] = ',';
					NB_NOTIFY5513_CMD[24 + j] = '5'; // 资源ID：5513（纬度）
					NB_NOTIFY5513_CMD[25 + j] = '5';
					NB_NOTIFY5513_CMD[26 + j] = '1';
					NB_NOTIFY5513_CMD[27 + j] = '3';
					NB_NOTIFY5513_CMD[28 + j] = ',';
					NB_NOTIFY5513_CMD[29 + j] = '1'; // 数据类型：字符串
					NB_NOTIFY5513_CMD[30 + j] = ',';
					NB_NOTIFY5513_CMD[31 + j] = '9'; // 数据长度
					NB_NOTIFY5513_CMD[32 + j] = ',';
					NB_NOTIFY5513_CMD[33 + j] = '\"'; // 字符串起始符
					NB_NOTIFY5513_CMD[43 + j] = '\"'; // 字符串结束符
					NB_NOTIFY5513_CMD[44 + j] = ',';
					NB_NOTIFY5513_CMD[45 + j] = '1'; // 标志位
					NB_NOTIFY5513_CMD[46 + j] = ',';
					NB_NOTIFY5513_CMD[47 + j] = '0';
					NB_NOTIFY5513_CMD[48 + j] = '\r'; // 指令结束符
					NB_NOTIFY5513_CMD[49 + j] = '\n';

					// 拼接经度上报指令（5514为经度资源ID）
					NB_NOTIFY5514_CMD[16 + j] = ',';
					NB_NOTIFY5514_CMD[17 + j] = '3'; // 对象ID：3336
					NB_NOTIFY5514_CMD[18 + j] = '3';
					NB_NOTIFY5514_CMD[19 + j] = '3';
					NB_NOTIFY5514_CMD[20 + j] = '6';
					NB_NOTIFY5514_CMD[21 + j] = ',';
					NB_NOTIFY5514_CMD[22 + j] = '0'; // 实例ID
					NB_NOTIFY5514_CMD[23 + j] = ',';
					NB_NOTIFY5514_CMD[24 + j] = '5'; // 资源ID：5514（经度）
					NB_NOTIFY5514_CMD[25 + j] = '5';
					NB_NOTIFY5514_CMD[26 + j] = '1';
					NB_NOTIFY5514_CMD[27 + j] = '4';
					NB_NOTIFY5514_CMD[28 + j] = ',';
					NB_NOTIFY5514_CMD[29 + j] = '1'; // 数据类型：字符串
					NB_NOTIFY5514_CMD[30 + j] = ',';
					NB_NOTIFY5514_CMD[31 + j] = '1'; // 数据长度
					NB_NOTIFY5514_CMD[32 + j] = '0';
					NB_NOTIFY5514_CMD[33 + j] = ',';
					NB_NOTIFY5514_CMD[34 + j] = '\"'; // 字符串起始符
					NB_NOTIFY5514_CMD[45 + j] = '\"'; // 字符串结束符
					NB_NOTIFY5514_CMD[46 + j] = ',';
					NB_NOTIFY5514_CMD[47 + j] = '0'; // 标志位
					NB_NOTIFY5514_CMD[48 + j] = ',';
					NB_NOTIFY5514_CMD[49 + j] = '0';
					NB_NOTIFY5514_CMD[50 + j] = '\r'; // 指令结束符
					NB_NOTIFY5514_CMD[51 + j] = '\n';
					NB_OB3336_count = j; // 记录3336对象参数长度，用于后续指令拼接
				}

				// 拼接观察者响应指令并发送
				NB_OBSERVERSP_CMD[20 + j] = ',';
				NB_OBSERVERSP_CMD[21 + j] = '1';  // 响应状态：成功
				NB_OBSERVERSP_CMD[22 + j] = '\r'; // 指令结束符
				NB_OBSERVERSP_CMD[23 + j] = '\n';
				// 拼接观察者响应指令NB_OBSERVERSP_CMD（响应状态 = 成功），通过Send_Cmd发送给 NB 模块，完成对平台的响应
				Send_Cmd(NB_OBSERVERSP_CMD, 24 + j, "OK"); // 发送响应
			}
		}
	}
	// 处理发现请求指令（+MIPLDISCOVER:）
	/**
	 * @brief 用于响应云平台发送的 “发现请求”（MIPL 协议中查询设备支持的资源 ID）
	 * 告知平台当前设备支持的电池和定位相关资源。
	*/
	else if (strstr((const char *)Res1_Buf, "+MIPLDISCOVER:"))
	{
		// 校验指令格式：第18位应为逗号（参数分隔符）
		if (Res1_Buf[18] == ',')
		{
			i = 0;
			// 提取逗号间的参数长度（最多10位，防止缓冲区溢出）
			while (Res1_Buf[19 + i] != ',' && i <= 10)
			{
				i++;
			}

			// 参数长度超过10，视为格式错误
			if (i > 10)
			{
				printf("+MIPLDISCOVER data format error\r\n");
			}
			else
			{
				// 拷贝参数到发现响应指令缓冲区
				for (j = 0; j < i; j++)
				{
					NB_DISCOVERRSP_CMD[21 + j] = Res1_Buf[19 + j];
				}

				// 处理3336对象（定位相关）的发现请求
				if (strstr((const char *)Res1_Buf, "3336"))
				{
					// 拼接发现响应指令（包含纬度/经度资源ID：5513;5514）
					NB_DISCOVERRSP_CMD[21 + j] = ',';
					NB_DISCOVERRSP_CMD[22 + j] = '1'; // 响应状态：成功
					NB_DISCOVERRSP_CMD[23 + j] = ',';
					NB_DISCOVERRSP_CMD[24 + j] = '9'; // 数据长度
					NB_DISCOVERRSP_CMD[25 + j] = ',';
					NB_DISCOVERRSP_CMD[26 + j] = '\"';
					NB_DISCOVERRSP_CMD[27 + j] = '5'; // 资源ID列表
					NB_DISCOVERRSP_CMD[28 + j] = '5';
					NB_DISCOVERRSP_CMD[29 + j] = '1';
					NB_DISCOVERRSP_CMD[30 + j] = '3';
					NB_DISCOVERRSP_CMD[31 + j] = ';';
					NB_DISCOVERRSP_CMD[32 + j] = '5';
					NB_DISCOVERRSP_CMD[33 + j] = '5';
					NB_DISCOVERRSP_CMD[34 + j] = '1';
					NB_DISCOVERRSP_CMD[35 + j] = '4';
					NB_DISCOVERRSP_CMD[36 + j] = '\"';
					NB_DISCOVERRSP_CMD[37 + j] = '\r'; // 指令结束符
					NB_DISCOVERRSP_CMD[38 + j] = '\n';
					Send_Cmd(NB_DISCOVERRSP_CMD, 39 + j, "OK"); // 发送响应
					onenet_ok++;								// 标记平台连接状态（定位对象就绪）
				}
				// 处理3320对象（电池相关）的发现请求
				else if (strstr((const char *)Res1_Buf, "3320"))
				{
					// 拼接发现响应指令（包含电量资源ID：5700）
					NB_DISCOVERRSP_CMD[21 + j] = ',';
					NB_DISCOVERRSP_CMD[22 + j] = '1'; // 响应状态：成功
					NB_DISCOVERRSP_CMD[23 + j] = ',';
					NB_DISCOVERRSP_CMD[24 + j] = '4'; // 数据长度
					NB_DISCOVERRSP_CMD[25 + j] = ',';
					NB_DISCOVERRSP_CMD[26 + j] = '\"';
					NB_DISCOVERRSP_CMD[27 + j] = '5'; // 资源ID：5700
					NB_DISCOVERRSP_CMD[28 + j] = '7';
					NB_DISCOVERRSP_CMD[29 + j] = '0';
					NB_DISCOVERRSP_CMD[30 + j] = '0';
					NB_DISCOVERRSP_CMD[31 + j] = '\"';
					NB_DISCOVERRSP_CMD[32 + j] = '\r'; // 指令结束符
					NB_DISCOVERRSP_CMD[33 + j] = '\n';
					Send_Cmd(NB_DISCOVERRSP_CMD, 34 + j, "OK"); // 发送响应
					onenet_ok++;								// 标记平台连接状态（电池对象就绪）
				}
			}
		}
	}

	// 处理GNSS定位数据（+QGNSSRD:）
	/**
	 * @brief 用于解析 NB 模块返回的 GNSS 定位原始数据（NMEA/RMC 格式），转换为经纬度并上报到云平台。
	*/
	if (strstr((const char *)Res1_Buf, "+QGNSSRD:"))
	{
		// 检查定位有效性：第29位为'A'表示定位成功（NMEA协议）
		if (Res1_Buf[29] == 'A')
		{
			// 示例数据格式：+QGNSSRD: $GNRMC,032956.42,A,3748.7157,N,11238.7823,E,...

			// 解析纬度（格式：ddmm.mmmm，转换为dd.dddddd°）
			// 提取mm.mmmm部分（33-39位：48.7157中的"487157"）
			temp_int = (Res1_Buf[33] - 0x30) * 100000 +
					   (Res1_Buf[34] - 0x30) * 10000 +
					   (Res1_Buf[36] - 0x30) * 1000 +
					   (Res1_Buf[37] - 0x30) * 100 +
					   (Res1_Buf[38] - 0x30) * 10 +
					   (Res1_Buf[39] - 0x30);
			// 转换为度分格式：mm.mmmm/60 = 小数度（如48.7157/60≈0.8119）
			temp_float = (float)temp_int / 600000;
			// 提取度部分（31-32位：37°）
			weidu_int = (Res1_Buf[31] - 0x30) * 10 + (Res1_Buf[32] - 0x30);
			// 合并为完整纬度（度+小数度）
			weidu_float = temp_float + (float)weidu_int;
			// 放大1e6倍转为整数（便于传输）
			weidu_float = weidu_float * 1000000;
			weidu_int = (uint32_t)weidu_float;

			// 填充纬度上报指令（字符串格式："dd.dddddd"）
			NB_NOTIFY5513_CMD[34 + NB_OB3336_count] = weidu_int / 10000000 + 0x30;			 // 十位
			NB_NOTIFY5513_CMD[35 + NB_OB3336_count] = weidu_int % 10000000 / 1000000 + 0x30; // 个位
			NB_NOTIFY5513_CMD[36 + NB_OB3336_count] = '.';									 // 小数点
			NB_NOTIFY5513_CMD[37 + NB_OB3336_count] = weidu_int % 1000000 / 100000 + 0x30;	 // 小数第1位
			NB_NOTIFY5513_CMD[38 + NB_OB3336_count] = weidu_int % 100000 / 10000 + 0x30;	 // 小数第2位
			NB_NOTIFY5513_CMD[39 + NB_OB3336_count] = weidu_int % 10000 / 1000 + 0x30;		 // 小数第3位
			NB_NOTIFY5513_CMD[40 + NB_OB3336_count] = weidu_int % 1000 / 100 + 0x30;		 // 小数第4位
			NB_NOTIFY5513_CMD[41 + NB_OB3336_count] = weidu_int % 100 / 10 + 0x30;			 // 小数第5位
			NB_NOTIFY5513_CMD[42 + NB_OB3336_count] = weidu_int % 10 + 0x30;				 // 小数第6位
			printf("Latitude=%d\r\n", weidu_int);

			// 解析经度（格式：dddmm.mmmm，转换为ddd.dddddd°）
			// 提取mm.mmmm部分（46-52位：38.7823中的"387823"）
			temp_int = (Res1_Buf[46] - 0x30) * 100000 +
					   (Res1_Buf[47] - 0x30) * 10000 +
					   (Res1_Buf[49] - 0x30) * 1000 +
					   (Res1_Buf[50] - 0x30) * 100 +
					   (Res1_Buf[51] - 0x30) * 10 +
					   (Res1_Buf[52] - 0x30);
			// 转换为度分格式：mm.mmmm/60 = 小数度（如38.7823/60≈0.6464）
			temp_float = (float)temp_int / 600000;
			// 提取度部分（43-45位：112°）
			jingdu_int = (Res1_Buf[43] - 0x30) * 100 + (Res1_Buf[44] - 0x30) * 10 + (Res1_Buf[45] - 0x30);
			// 合并为完整经度（度+小数度）
			jingdu_float = temp_float + (float)jingdu_int;
			// 放大1e6倍转为整数（便于传输）
			jingdu_float = jingdu_float * 1000000;
			jingdu_int = (uint32_t)jingdu_float;

			// 填充经度上报指令（字符串格式："ddd.dddddd"）
			NB_NOTIFY5514_CMD[35 + NB_OB3336_count] = jingdu_int / 100000000 + 0x30;			// 百位
			NB_NOTIFY5514_CMD[36 + NB_OB3336_count] = jingdu_int % 100000000 / 10000000 + 0x30; // 十位
			NB_NOTIFY5514_CMD[37 + NB_OB3336_count] = jingdu_int % 10000000 / 1000000 + 0x30;	// 个位
			NB_NOTIFY5514_CMD[38 + NB_OB3336_count] = '.';										// 小数点
			NB_NOTIFY5514_CMD[39 + NB_OB3336_count] = jingdu_int % 1000000 / 100000 + 0x30;		// 小数第1位
			NB_NOTIFY5514_CMD[40 + NB_OB3336_count] = jingdu_int % 100000 / 10000 + 0x30;		// 小数第2位
			NB_NOTIFY5514_CMD[41 + NB_OB3336_count] = jingdu_int % 10000 / 1000 + 0x30;			// 小数第3位
			NB_NOTIFY5514_CMD[42 + NB_OB3336_count] = jingdu_int % 1000 / 100 + 0x30;			// 小数第4位
			NB_NOTIFY5514_CMD[43 + NB_OB3336_count] = jingdu_int % 100 / 10 + 0x30;				// 小数第5位
			NB_NOTIFY5514_CMD[44 + NB_OB3336_count] = jingdu_int % 10 + 0x30;					// 小数第6位
			printf("Longitude=%d\r\n", jingdu_int);

			// 上报经纬度数据到OneNET云平台
			Send_Cmd(NB_NOTIFY5513_CMD, 50 + NB_OB3336_count, "OK");
			HAL_UART_Transmit(&huart2, NB_NOTIFY5513_CMD, 50 + NB_OB3336_count, 1000); // 调试打印
			Send_Cmd(NB_NOTIFY5514_CMD, 52 + NB_OB3336_count, "OK");
			HAL_UART_Transmit(&huart2, NB_NOTIFY5514_CMD, 52 + NB_OB3336_count, 1000); // 调试打印
		}
	}
}
/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */

	/* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
	   tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
